<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Oceanic data</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Custom fonts for this template-->
        <link href="{{ asset('vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <!-- Custom styles for this template-->
        <link href= "{{ asset('vendor/sb-admin-2.min.css') }}" rel="stylesheet">
        <script type="text/javascript" src="{{ asset('libs/FileSaver/FileSaver.min.js') }}"></script>
        <script type="text/javascript" src="{{ asset('libs/js-xlsx/xlsx.core.min.js') }}"></script>
        <script type="text/javascript" src="{{ asset('tableExport.min.js')}}"></script>

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                margin: 0;
                padding-left: 2em;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
            }

            td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
            }

            tr:nth-child(even) {
                background-color: #dddddd;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                    Mobile Data
                </div>
                <a href="#" class="btn btn-success" onClick ="$('#dataTable').tableExport({type:'excel',escape:'false'});">Export to Excel</a>
                {{-- <a href="{{ route('export.excel') }}" class="btn btn-success">Export to Excel</a> --}}
                
                <div class="card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <tr>
                            <th>Retailer</th>
                            <th>City</th>
                            <th>Brands</th>
                            <th>Model</th>
                            <th>Brand + Model</th>
                            <th>Sales Units</th>
                            <th>Unit price</th>
                            <th>Sales Value</th>
                            {{-- <th>MOB SMP</th> --}}
                        </tr>
                        @foreach ($collections as $collection)
                            <tr>
                                <td>{{ $collection['Retailer'] ?? ' ' }}</td>
                                <td>{{ $collection['City'] ?? ' ' }}</td>
                                <td>{{ $collection['A_Brands'] ?? ' ' }}</td>
                                <td>{{ $collection['C_Model'] ?? '' }}</td>
                                <td> {{ $collection['A_Brands'] ?? ' ' }} {{ $collection['C_Model'] ?? '' }}</td>
                                <td>{{ $collection['F_Sales units'] ?? '' }}</td>
                                <td>{{ $collection['G_Unit price'] ?? '' }}</td>
                                <td>
                                    {{ number_format(($collection['F_Sales units'] ?? 0) * ($collection['G_Unit price'] ?? 0)) }}
                                </td>
                                {{-- <td>{{ $collection['H_MOB SMP'] ?? '' }}</td> --}}
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
         <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Bootstrap core JavaScript-->
        {{-- <script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script> --}}
        <script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

        <!-- Core plugin JavaScript-->
        <script src="{{ asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>

        <!-- Custom scripts for all pages-->
        <script src="{{ asset('vendor/sb-admin-2.min.js') }}"></script>
		
        
    </body>
</html>
