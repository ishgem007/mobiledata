<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;

class DataExport implements FromArray
{
  // public function collection()
  // {
  //   return session('collections');
    
  // }
  public function array(): array
  {
    return session('collections');
  }
}